# 볼린저 밴드 지표 : 밴드폭
# 밴드폭은 상단 볼린저 밴드와 하단 볼린저 밴드 사이의 폭을 의미한다. 밴드폭은 스퀴즈를 확인하는 데 유용한 지표이다.
# 스퀴즈란 변동성이 극히 낮은 수준까지 떨어져 곧이어 변동성 증가가 발생할 것으로 예상되는 상황을 말한다. 
# 볼린저가 저술한 바에 따르면 밴드폭이 6개월 저점을 기록하는 것을 보고 스퀴즈를 파악할 수 있다고 한다.
# 밴드폭 =(상단 볼린저 밴드-하단 볼린저 밴드)/중간 볼린저 밴드
import matplotlib.pyplot as plt
from investar import Analyzer

mk = Analyzer.MarketDB()
df = mk.get_daily_price('NAVER', '2019-01-02')
  
df['MA20'] = df['close'].rolling(window=20).mean() 
df['stddev'] = df['close'].rolling(window=20).std() 
df['upper'] = df['MA20'] + (df['stddev'] * 2)
df['lower'] = df['MA20'] - (df['stddev'] * 2)
df['bandwidth'] = (df['close'] - df['lower']) / ( df['MA20']) *100  #이부분
df = df[19:]

plt.figure(figsize=(9, 8))
plt.subplot(2, 1, 1)  # 이부분이 앞의 파일과 다르다.
plt.plot(df.index, df['close'], color='#0000ff', label='Close')
plt.plot(df.index, df['upper'], 'r--', label = 'Upper band')
plt.plot(df.index, df['MA20'], 'k--', label='Moving average 20')
plt.plot(df.index, df['lower'], 'c--', label = 'Lower band')
plt.fill_between(df.index, df['upper'], df['lower'], color='0.9')
plt.title('NAVER Bollinger Band(20 day, 2 std)')
plt.legend(loc='best')

plt.subplot(2, 1, 2)  
plt.plot(df.index, df['bandwidth'], color='m', label='BandWidth')  
plt.grid(True)
plt.legend(loc='best')
plt.show()