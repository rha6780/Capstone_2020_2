# 볼린저 밴드 지표
#볼린저 밴드 공식
#-상단 볼린저 밴드=중간볼린저 밴드 +(2*표준편차)
#-중간 볼린저 밴드=종가의 20일 이동평균
#-하단 볼린저 밴드=중간볼린저 밴드 +(2*표준편차)
#네이버에 종가(close), 상단 볼린저(upper), 중간 볼린저 밴드(MA20), 하단 볼린저 밴드(lower)
import matplotlib.pyplot as plt
from investar import Analyzer

mk = Analyzer.MarketDB()
df = mk.get_daily_price('NAVER', '2019-01-02')
  
df['MA20'] = df['close'].rolling(window=20).mean() 
df['stddev'] = df['close'].rolling(window=20).std() 
df['upper'] = df['MA20'] + (df['stddev'] * 2)   
df['lower'] = df['MA20'] - (df['stddev'] * 2)   
df = df[19:]  

plt.figure(figsize=(9, 5))
plt.plot(df.index, df['close'], color='#0000ff', label='Close')    
plt.plot(df.index, df['upper'], 'r--', label = 'Upper band')       
plt.plot(df.index, df['MA20'], 'k--', label='Moving average 20')
plt.plot(df.index, df['lower'], 'c--', label = 'Lower band')
plt.fill_between(df.index, df['upper'], df['lower'], color='0.9')   
plt.legend(loc='best')
plt.title('NAVER Bollinger Band (20 day, 2 std)')
plt.show()